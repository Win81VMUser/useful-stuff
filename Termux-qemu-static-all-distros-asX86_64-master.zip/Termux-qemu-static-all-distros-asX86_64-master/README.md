#Termux-qemu-static-all-distros-as X86_64

Resources Provided By
https://github.com/EXALAB and https://github.com/AndronixApp/AndronixOrigin

it like chroot different Architecture Using QEMU No root On Android Armhf/Aarch64


Credits go to AkiraYuki
