apt update && apt upgrade && apt install lxqt tigervnc-standalone-server
